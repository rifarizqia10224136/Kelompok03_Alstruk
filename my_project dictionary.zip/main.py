# menggunakan index
data_list = ['Rifdal', 'Haikal', 'Zidan']

print(data_list[0])

# dictionary (dict) -> associative array
# identifier -> key
data_dict = {
    'key': 'value',
    'rf': 'Rifdal',
    'hk': 'Haikal',
    'zd': 'Zidan',
    'nmbr': 100,
    'list': data_list,
}

print(data_dict['hk'])
print(data_dict['nmbr'])
print(data_dict['list'])
